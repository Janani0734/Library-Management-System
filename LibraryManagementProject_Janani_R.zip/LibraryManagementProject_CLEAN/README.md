# Library Management System — Janani R

This is a simple Java-based Library Management System built using core Java concepts, basic data handling, and an optional SQL schema.

## Features
- Add a book
- List books
- Runs fully in demo mode without database
- SQL file included for optional DB setup

## Technologies Used
- Java
- Optional JDBC
- SQL (MySQL schema)
- HTML, CSS, JavaScript (static UI)

## Project Structure
src/com/janani/library
sql/
web/
docs/

## How to Run
1. javac -d bin src/com/janani/library/*.java
2. java -cp bin com.janani.library.Main
