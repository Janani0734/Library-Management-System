package com.janani.library;

import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("=== Library Management System (Demo) ===");

        while(true){
            System.out.println("Options: 1) List Books 2) Add Book 3) Exit");
            System.out.print("Choose option: ");
            String s = sc.nextLine().trim();
            int opt;
            try { opt = Integer.parseInt(s); } catch(Exception e){ continue; }

            if(opt == 1){
                BookDAO.listBooks();
            }else if(opt == 2){
                System.out.print("Enter title: ");
                String t = sc.nextLine();
                System.out.print("Enter author: ");
                String a = sc.nextLine();
                BookDAO.addBook(new Book(t,a));
            }else if(opt == 3){
                System.out.println("Goodbye!");
                break;
            }
        }
        sc.close();
    }
}
