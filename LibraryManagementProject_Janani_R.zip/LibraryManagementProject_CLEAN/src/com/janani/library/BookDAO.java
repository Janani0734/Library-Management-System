package com.janani.library;

import java.util.ArrayList;
import java.util.List;

public class BookDAO {

    private static final List<Book> demo = new ArrayList<>();

    static {
        demo.add(new Book(1,"The Alchemist","Paulo Coelho"));
        demo.add(new Book(2,"Clean Code","Robert C. Martin"));
    }

    public static void listBooks(){
        System.out.println("-- Books --");
        for(Book b: demo){
            System.out.println(b.getId()+". "+b.getTitle()+" - "+b.getAuthor());
        }
    }

    public static void addBook(Book b){
        demo.add(new Book(demo.size()+1, b.getTitle(), b.getAuthor()));
        System.out.println("Book added.");
    }
}
